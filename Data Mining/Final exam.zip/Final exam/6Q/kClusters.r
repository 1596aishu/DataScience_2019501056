setwd("C:\\Users\\aishwarya\\Desktop\\Final exam\\6Q\\")
data = read.csv("Liver_Data.csv", header = FALSE, col.names = c("mcv", "alkphos", "sgpt", "sgot", "gammagt", "drinks", "selector"))
head(data)
