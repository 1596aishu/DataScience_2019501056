setwd("C:\\Users\\aishwarya\\Desktop\\Final exam\\3Q\\")
data = read.csv("lenses.data.csv", header = TRUE)
head(data)

library(rpart)
b <- as.factor(data[,5])
a <- data[,1:4]

fit <- rpart(b~.,a,method = 'class')
library(rpart.plot)
rpart.plot(fit,extra=106)

#information gain
gain<- sum(b == predict(fit, a, type = "class"))/length(b)
gain

#error rate
error <- 1-gain
error