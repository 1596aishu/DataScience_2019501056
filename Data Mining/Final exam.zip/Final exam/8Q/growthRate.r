setwd("C:\\Users\\aishwarya\\Desktop\\Final exam\\8Q\\")
data = read.csv("BSE_Sensex_Index.csv", header = TRUE)
head(data)
data$Date = as.Date(data$Date, format='%m/%d/%Y')

new<- c()
for(i in 1:15446){
  new[i]<- (data$Close[i] - data$Close[i+1]) / data$Close[i+1]
}
new[15447]<- (new[15446]+new[15445]+new[15444]) /3
print(new[15447])

data["new"] = new
print(data)

#z-scores
sgrmean <- mean(data$new, na.rm=TRUE)
sgrsd <- sd(data$new,na.rm=TRUE)
z<-(data$new - sgrmean) / sgrsd
sort(z)
data$zscores <- z
dates<-subset(data[,1],data[,"zscores"] >= 3.0 | data[,"zscores"] <= -3.0)
print(dates)

write.csv(dates,"Dates-Outliers.csv",quote = FALSE,row.names = TRUE)
