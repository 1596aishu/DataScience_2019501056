# import pandas as pd
# import numpy as np

# #read the csv file
# data = pd.read_csv("C:\\Users\\aishwarya\\Desktop\\Final exam\\BSE_Sensex_Index.csv")
# df = pd.DataFrame(data)

# #calculate the difference of successive row values
# df['open_new'] = df['Open'].diff(1)
# df['high_new'] = df['High'].diff(1)
# df['low_new'] = df['Low'].diff(1)
# df['close_new'] = df['Close'].diff(1) 
# df['volume_new'] = df['Volume'].diff(1) 
# df['adj_new'] = df['Adj Close'].diff(1)
# print(df)

# # Calculate the mean, max, varience and 1st quartile
# df_mean = df[["open_new", "high_new", "low_new", "close_new", "volume_new", "adj_new"]].mean()
# print("Mean: ")
# print(df_mean)
# df_max = df[["open_new", "high_new", "low_new", "close_new", "volume_new", "adj_new"]].max()
# print("Max: ")
# print(df_max)
# df_var = df[["open_new", "high_new", "low_new", "close_new", "volume_new", "adj_new"]].var()
# print("Varience: ")
# print(df_var)
# df_quar = df[["open_new", "high_new", "low_new", "close_new", "volume_new", "adj_new"]].quantile([0.25,0.5,0.75])
# print("1st Quartile: ")
# print(df_quar)

# # Comparing the values with the whole dataframe and the newly generated values
# print(df.mean())
# print(df.max())
# print(df.var())
# print(df.quantile([0.25,0.5,0.75]))



